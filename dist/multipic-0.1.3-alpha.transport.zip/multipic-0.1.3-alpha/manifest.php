<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '# MultiPic

Массовая загрузка изображений в TV MODX Revolution: компактные миниатюры, сортировка, название/ALT, скрытие, несколько галерей на ресурсе и подключение через `inputTV` в MIGX.

**Текущая версия: 0.1.3-alpha. Целевая ветка: MODX 2.x начиная с 2.6.0, PHP 7.4+. Проверены MODX 2.6.0, 2.6.5, 2.8.5 и 2.8.6 на PHP 7.4.** Это технический выпуск для отдельного тестового сайта. MODX 3 пока исключён из установочных требований. [Результаты проверки и ограничения](docs/STATUS.md).

## Установка

1. Скачать [multipic-0.1.3-alpha.transport.zip](dist/multipic-0.1.3-alpha.transport.zip).
2. В менеджере MODX открыть «Управление пакетами», выбрать локальную загрузку и установить этот `.transport.zip`.
3. Создать TV, например `gallery`, с типом **MultiPic — галерея изображений**.
4. Указать максимум файлов и папку, например `multipic/gallery/`. На вкладке «Источники файлов» выбрать локальный файловый источник.
5. Назначить TV нужному шаблону. Открыть ресурс, загрузить фотографии, сохранить ресурс.

После установки появляются категория **MultiPic**, сниппет, плагин, настройки и примеры чанков. Самостоятельно ресурсы и TV на сайте не создаются. При обновлении пользовательские изменения демонстрационных чанков сохраняются.

Сторонние дополнения для самостоятельной работы не нужны. Требования к платформе проверяются валидатором установки без вкладки пакетных зависимостей. Требуются PHP JSON, PDO MySQL, GD, Fileinfo и EXIF. Для WebP библиотека GD должна поддерживать этот формат. Таблицы InnoDB; рекомендуется MySQL 5.7+/MariaDB. Автоматическая очистка использует MySQL advisory locks.

## Вывод

```modx
[[MultiPic?
    &tv=`gallery`
    &tpl=`multipicItem`
    &tplWrapper=`multipicWrapper`
]]
```

Одна фотография другого ресурса:

```modx
[[MultiPic? &tv=`gallery` &resource=`123` &limit=`1`]]
```

Поддерживаются обычные чанки из админки, статические чанки по имени и файлы через `@FILE`. Примеры сниппета и Fenom `foreach` установлены в категории MultiPic. [Полная справка по текущей реализации](docs/USAGE.md).

## Документация

- [Настройка, MIGX, вывод, foreach, хранение и cron](docs/USAGE.md)
- [Что проверить на тестовом сайте](docs/ACCEPTANCE.md)
- [Согласованное техническое задание](docs/SPEC.md)
- [Статус и известные ограничения](docs/STATUS.md)
- [Изменения](CHANGELOG.md)

## Сборка из исходников

На отдельной установленной копии MODX 2.8.6:

```bash
php _build/build.transport.php /absolute/path/to/site/config.core.php
```

Результат: `core/packages/multipic-0.1.3-alpha.transport.zip` используемой установки. Сборщик не публикует пакет и не устанавливает его автоматически.

## Проверки

```bash
php tests/gallery.php
php tests/image.php
php tests/snippet.php
node --check assets/components/multipic/js/multipic.js
node tests/editor.cjs
```

Проверка [MODX 2.6.0, 2.6.5, 2.8.5 и 2.8.6 / PHP 7.4.33 / MySQL 5.7 прошла](https://github.com/olegvarnavski/multipic/actions/runs/39100947199): установка, загрузка, дедупликация, вывод, копирование ресурса и удаление файлов. Установщик в dist взят из задания MODX 2.8.5 этого прогона. Для DOM-тестов разработчика: `npm ci && npm test`; на сайт Node/npm не устанавливаются. Ручная приёмка реального менеджера и MIGX ещё нужна.

Не запускайте `tests/integration.php` на рабочем сайте: он создаёт тестовые ресурсы и проверяет физическое удаление своих файлов.
',
    'license' => 'Copyright 2026. MultiPic project.',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '88e0e05d3a328bfb0c67cf94e5dccd0d',
      'native_key' => 'multipic',
      'filename' => 'modNamespace/9051066e3403187dfe67b7e388643eb9.vehicle',
      'namespace' => 'multipic',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c6f96604bb43abec1f078aef94acad98',
      'native_key' => 'multipic.folder',
      'filename' => 'modSystemSetting/8855fa4b5b940c2ea5b52239587e8059.vehicle',
      'namespace' => 'multipic',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9f8f0da292b549721810fe02e8d318f',
      'native_key' => 'multipic.max_files',
      'filename' => 'modSystemSetting/c1510b1f6d58d21a899c701c4ac07176.vehicle',
      'namespace' => 'multipic',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd2982428a2e3d7ce148b64398f3230ae',
      'native_key' => 'multipic.max_edge',
      'filename' => 'modSystemSetting/592565886c070932a4e24156d73d4b57.vehicle',
      'namespace' => 'multipic',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db5b23978f0e00b8b32f214da43984a7',
      'native_key' => 'multipic.quality',
      'filename' => 'modSystemSetting/080acc4742995f53065366a5f1c27f71.vehicle',
      'namespace' => 'multipic',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7c9c48f1b90b0a43360f93d89e7f7be',
      'native_key' => 'multipic.max_bytes',
      'filename' => 'modSystemSetting/ef74a5d650351df5322cb5101452c66a.vehicle',
      'namespace' => 'multipic',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '249ae0e7f2c3bc051a1e61e1ff073b1f',
      'native_key' => 'multipic.max_pixels',
      'filename' => 'modSystemSetting/5195aaebc5324a34b96f611825246502.vehicle',
      'namespace' => 'multipic',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '105da2d55715e685a33f58e23e95ea5a',
      'native_key' => 'multipic.chunks_path',
      'filename' => 'modSystemSetting/3025b18eeb3e727a26163cadd7602f91.vehicle',
      'namespace' => 'multipic',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '73cdd9f30fb94e6bf6fd72de59172dd4',
      'native_key' => NULL,
      'filename' => 'modCategory/ad747c58f8832151fc59a9614877945d.vehicle',
      'namespace' => 'multipic',
    ),
  ),
);