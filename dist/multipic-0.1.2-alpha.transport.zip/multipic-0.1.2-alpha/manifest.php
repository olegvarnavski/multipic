<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '# MultiPic

Массовая загрузка изображений в TV MODX Revolution: компактные миниатюры, сортировка, название/ALT, скрытие, несколько галерей на ресурсе и подключение через `inputTV` в MIGX.

**Текущая версия: 0.1.2-alpha. Целевая ветка: MODX 2.x начиная с 2.6.0, PHP 7.4+. Проверка старых версий выполняется в матрице CI.** Это технический выпуск для отдельного тестового сайта. MODX 3 пока исключён из установочных требований. [Результаты проверки и ограничения](docs/STATUS.md).

## Установка

1. Скачать [multipic-0.1.2-alpha.transport.zip](dist/multipic-0.1.2-alpha.transport.zip).
2. В менеджере MODX открыть «Управление пакетами», выбрать локальную загрузку и установить этот `.transport.zip`.
3. Создать TV, например `gallery`, с типом **MultiPic — галерея изображений**.
4. Указать максимум файлов и папку, например `multipic/gallery/`. На вкладке «Источники файлов» выбрать локальный файловый источник.
5. Назначить TV нужному шаблону. Открыть ресурс, загрузить фотографии, сохранить ресурс.

После установки появляются категория **MultiPic**, сниппет, плагин, настройки и примеры чанков. Самостоятельно ресурсы и TV на сайте не создаются. При обновлении пользовательские изменения демонстрационных чанков сохраняются.

Сторонние дополнения для самостоятельной работы не нужны. Требования к платформе проверяются валидатором установки без вкладки пакетных зависимостей. Требуются PHP JSON, PDO MySQL, GD, Fileinfo и EXIF. Для WebP библиотека GD должна поддерживать этот формат. Таблицы InnoDB; рекомендуется MySQL 5.7+/MariaDB. Автоматическая очистка использует MySQL advisory locks.

## Вывод

```modx
[[MultiPic?
    &tv=`gallery`
    &tpl=`multipicItem`
    &tplWrapper=`multipicWrapper`
]]
```

Одна фотография другого ресурса:

```modx
[[MultiPic? &tv=`gallery` &resource=`123` &limit=`1`]]
```

Поддерживаются обычные чанки из админки, статические чанки по имени и файлы через `@FILE`. Примеры сниппета и Fenom `foreach` установлены в категории MultiPic. [Полная справка по текущей реализации](docs/USAGE.md).

## Документация

- [Настройка, MIGX, вывод, foreach, хранение и cron](docs/USAGE.md)
- [Что проверить на тестовом сайте](docs/ACCEPTANCE.md)
- [Согласованное техническое задание](docs/SPEC.md)
- [Статус и известные ограничения](docs/STATUS.md)
- [Изменения](CHANGELOG.md)

## Сборка из исходников

На отдельной установленной копии MODX 2.8.6:

```bash
php _build/build.transport.php /absolute/path/to/site/config.core.php
```

Результат: `core/packages/multipic-0.1.2-alpha.transport.zip` используемой установки. Сборщик не публикует пакет и не устанавливает его автоматически.

## Проверки

```bash
php tests/gallery.php
php tests/image.php
php tests/snippet.php
node --check assets/components/multipic/js/multipic.js
node tests/editor.cjs
```

Проверка [MODX 2.8.6 / PHP 7.4.33 / MySQL 5.7 прошла](https://github.com/olegvarnavski/multipic/actions/runs/39099817949): установка, загрузка, дедупликация, вывод, копирование ресурса и удаление файлов. Установщик в dist взят из этого прогона. Для DOM-тестов разработчика: `npm ci && npm test`; на сайт Node/npm не устанавливаются. Ручная приёмка реального менеджера и MIGX ещё нужна.

Не запускайте `tests/integration.php` на рабочем сайте: он создаёт тестовые ресурсы и проверяет физическое удаление своих файлов.
',
    'license' => 'Copyright 2026. MultiPic project.',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '0b0ccd67e966ee0f67e31813040ee799',
      'native_key' => 'multipic',
      'filename' => 'modNamespace/bea3845457d803325aa7c489648b2726.vehicle',
      'namespace' => 'multipic',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '548f6e8362d70a1bdd6392da759d38d4',
      'native_key' => 'multipic.folder',
      'filename' => 'modSystemSetting/0433473289f6cdedf7a0ecd44fdbdae6.vehicle',
      'namespace' => 'multipic',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '08ad1d13a922365294b695d363e641a1',
      'native_key' => 'multipic.max_files',
      'filename' => 'modSystemSetting/947c39774c483b6d9f33a335e6bdbf6a.vehicle',
      'namespace' => 'multipic',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5cc7e1153b60465c2b36c7e637cbd7c9',
      'native_key' => 'multipic.max_edge',
      'filename' => 'modSystemSetting/04514d074eb3acf599386a8ace47fa2a.vehicle',
      'namespace' => 'multipic',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '58b8ba72cc248d8faee08eea510d4a7c',
      'native_key' => 'multipic.quality',
      'filename' => 'modSystemSetting/b63a56a6638132d67c597753a1c013f6.vehicle',
      'namespace' => 'multipic',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d5ccd4989e9d1bced1040db1a402f41',
      'native_key' => 'multipic.max_bytes',
      'filename' => 'modSystemSetting/27704c515ae51953a9366474dcd03e90.vehicle',
      'namespace' => 'multipic',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '591c1f6159126672ecfe22426510f09d',
      'native_key' => 'multipic.max_pixels',
      'filename' => 'modSystemSetting/e3497ec08bceaad549a4053a8d3e6ef9.vehicle',
      'namespace' => 'multipic',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0ad62929779905c337ac96908cfb8044',
      'native_key' => 'multipic.chunks_path',
      'filename' => 'modSystemSetting/092520f09c7ca41a7a8084f546ccfc24.vehicle',
      'namespace' => 'multipic',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '16ce88fd5a57d483f74376abbb3a821b',
      'native_key' => NULL,
      'filename' => 'modCategory/41e90511e02ddb558e76b68c95fb3215.vehicle',
      'namespace' => 'multipic',
    ),
  ),
);