<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '# MultiPic

Массовая загрузка изображений в TV MODX Revolution: компактные миниатюры, сортировка, название/ALT, скрытие, несколько галерей на ресурсе и подключение через `inputTV` в MIGX.

**Текущая версия: 0.2.0-alpha. Целевая ветка: MODX 2.x начиная с 2.6.0, PHP 7.4+ (полная интеграция проверяется на PHP 7.4, PHP 8.2 — отдельно unit). Проверены MODX 2.6.0, 2.6.5, 2.8.5 и 2.8.6 на PHP 7.4.** Это технический выпуск для отдельного тестового сайта. MODX 3 пока исключён из установочных требований. [Результаты проверки и ограничения](docs/STATUS.md).

Новые фотографии хранятся в папках по ID ресурса; миниатюры — в отдельном восстанавливаемом кеше. [Обновление и перенос старых галерей](docs/STORAGE-PROPOSAL.md).

## Установка

1. Скачать [multipic-0.2.0-alpha.transport.zip](dist/multipic-0.2.0-alpha.transport.zip).
2. В менеджере MODX открыть «Управление пакетами», выбрать локальную загрузку и установить этот `.transport.zip`.
3. Создать TV, например `gallery`, с типом **MultiPic — галерея изображений**.
4. Указать максимум файлов и папку, например `multipic/gallery/`. На вкладке «Источники файлов» выбрать локальный файловый источник.
5. Назначить TV нужному шаблону. Открыть ресурс, загрузить фотографии, сохранить ресурс.

После установки появляются категория **MultiPic**, сниппет, плагин, настройки и примеры чанков. Самостоятельно ресурсы и TV на сайте не создаются. При обновлении пользовательские изменения демонстрационных чанков сохраняются.

Сторонние дополнения для самостоятельной работы не нужны. Для загрузки пользователь должен иметь право `file_upload`; ограничения типов источника учитываются. Требования к платформе проверяются валидатором установки без вкладки пакетных зависимостей. Требуются PHP JSON, PDO MySQL, GD, Fileinfo и EXIF. Для WebP библиотека GD должна поддерживать этот формат. Таблицы InnoDB; рекомендуется MySQL 5.7+/MariaDB. Автоматическая очистка использует MySQL advisory locks.

## Вывод

```modx
[[MultiPic?
    &tv=`gallery`
    &tpl=`multipicItem`
    &tplWrapper=`multipicWrapper`
]]
```

Одна фотография другого ресурса:

```modx
[[MultiPic? &tv=`gallery` &resource=`123` &limit=`1`]]
```

Поддерживаются обычные чанки из админки, статические чанки по имени и файлы через `@FILE`. Примеры сниппета и Fenom `foreach` установлены в категории MultiPic. [Полная справка по текущей реализации](docs/USAGE.md).

## Документация

- [Оставшиеся задачи и ручная приёмка](docs/ROADMAP.md)

- [Настройка, MIGX, вывод, foreach, хранение и cron](docs/USAGE.md)
- [Что проверить на тестовом сайте](docs/ACCEPTANCE.md)
- [Согласованное техническое задание](docs/SPEC.md)
- [Статус и известные ограничения](docs/STATUS.md)
- [Изменения](CHANGELOG.md)

## Сборка из исходников

На отдельной установленной копии MODX 2.8.6:

```bash
php _build/build.transport.php /absolute/path/to/site/config.core.php
```

Результат: `core/packages/multipic-0.2.0-alpha.transport.zip` используемой установки. Сборщик не публикует пакет и не устанавливает его автоматически.

## Проверки

```bash
php tests/gallery.php
php tests/image.php
php tests/snippet.php
node --check assets/components/multipic/js/multipic.js
node tests/editor.cjs
```

Предыдущий выпуск 0.1.7: проверка [MODX 2.6.0, 2.6.5, 2.8.5 и 2.8.6 / PHP 7.4.33 / MySQL 5.7 прошла](https://github.com/olegvarnavski/multipic/actions/runs/40326834479): установка, загрузка, дедупликация, вывод, копирование ресурса и удаление файлов. Также проверены вход/рендер TV/загрузка/сохранение ресурса через HTTP и токены при раннем закрытии PHP-сессии. Установщик в dist взят из задания MODX 2.8.5 этого прогона. Проверено обновление с 0.1.3 с сохранением пользовательских данных и отдельные unit на PHP 8.2. Для DOM-тестов разработчика: `npm ci && npm test`; на сайт Node/npm не устанавливаются. Ручная приёмка реального менеджера и MIGX ещё нужна.

Не запускайте `tests/integration.php` на рабочем сайте: он создаёт тестовые ресурсы и проверяет физическое удаление своих файлов.
',
    'license' => 'Copyright 2026. MultiPic project.',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '1fce8b501ab4381b12fe12f485f6ba4d',
      'native_key' => 'multipic',
      'filename' => 'modNamespace/1567db6b2076b2c9f2ef8dc5f2eef33e.vehicle',
      'namespace' => 'multipic',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9e3793b676292197d9658f528751454',
      'native_key' => 'multipic.folder',
      'filename' => 'modSystemSetting/98a935eeb19d222f6a9aa568fc233850.vehicle',
      'namespace' => 'multipic',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16984955a7bddced5640e08fc7060759',
      'native_key' => 'multipic.max_files',
      'filename' => 'modSystemSetting/482aab549e69557f3d2306c6eee69ce4.vehicle',
      'namespace' => 'multipic',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5fbd49a5555a2a06a4014445addbf3f5',
      'native_key' => 'multipic.max_edge',
      'filename' => 'modSystemSetting/20142b7dd3ee8212f8a8953e2eb1dfd0.vehicle',
      'namespace' => 'multipic',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a81bcb3e866021942c6881c1ec44ea9f',
      'native_key' => 'multipic.quality',
      'filename' => 'modSystemSetting/1746a6d173a811b9ccc4d240de632313.vehicle',
      'namespace' => 'multipic',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa06e9ec0a4e9e45c0d9faa20c85d04e',
      'native_key' => 'multipic.max_bytes',
      'filename' => 'modSystemSetting/1bffa40b4b321e714fd086b1e01e56e1.vehicle',
      'namespace' => 'multipic',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c1d0465ea84cea316a95fd0dfafb5707',
      'native_key' => 'multipic.chunks_path',
      'filename' => 'modSystemSetting/58e50d32e25647bbdff21e298af421e6.vehicle',
      'namespace' => 'multipic',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '7d09f73d7bf59e452c2063d2c8ac2502',
      'native_key' => NULL,
      'filename' => 'modCategory/9a3ae26eb3fea0b88160a577c5e33e64.vehicle',
      'namespace' => 'multipic',
    ),
  ),
);