<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '# MultiPic

Массовая загрузка изображений в TV MODX Revolution: компактные миниатюры, сортировка, название/ALT, скрытие, несколько галерей на ресурсе и подключение через `inputTV` в MIGX.

**Текущая версия: 0.1.1-alpha. Основная тестовая связка: MODX 2.8.6-pl + PHP 7.4.** Это технический выпуск для отдельного тестового сайта. MODX 3 пока исключён из установочных требований. [Результаты проверки и ограничения](docs/STATUS.md).

## Установка

1. Скачать [multipic-0.1.1-alpha.transport.zip](dist/multipic-0.1.1-alpha.transport.zip).
2. В менеджере MODX открыть «Управление пакетами», выбрать локальную загрузку и установить этот `.transport.zip`.
3. Создать TV, например `gallery`, с типом **MultiPic — галерея изображений**.
4. Указать максимум файлов и папку, например `multipic/gallery/`. На вкладке «Источники файлов» выбрать локальный файловый источник.
5. Назначить TV нужному шаблону. Открыть ресурс, загрузить фотографии, сохранить ресурс.

После установки появляются категория **MultiPic**, сниппет, плагин, настройки и примеры чанков. Самостоятельно ресурсы и TV на сайте не создаются. При обновлении пользовательские изменения демонстрационных чанков сохраняются.

Требуются PHP JSON, PDO MySQL, GD, Fileinfo и EXIF. Для WebP библиотека GD должна поддерживать этот формат. Таблицы InnoDB; рекомендуется MySQL 5.7+/MariaDB. Автоматическая очистка использует MySQL advisory locks.

## Вывод

```modx
[[MultiPic?
    &tv=`gallery`
    &tpl=`multipicItem`
    &tplWrapper=`multipicWrapper`
]]
```

Одна фотография другого ресурса:

```modx
[[MultiPic? &tv=`gallery` &resource=`123` &limit=`1`]]
```

Поддерживаются обычные чанки из админки, статические чанки по имени и файлы через `@FILE`. Примеры сниппета и Fenom `foreach` установлены в категории MultiPic. [Полная справка по текущей реализации](docs/USAGE.md).

## Документация

- [Настройка, MIGX, вывод, foreach, хранение и cron](docs/USAGE.md)
- [Что проверить на тестовом сайте](docs/ACCEPTANCE.md)
- [Согласованное техническое задание](docs/SPEC.md)
- [Статус и известные ограничения](docs/STATUS.md)
- [Изменения](CHANGELOG.md)

## Сборка из исходников

На отдельной установленной копии MODX 2.8.6:

```bash
php _build/build.transport.php /absolute/path/to/site/config.core.php
```

Результат: `core/packages/multipic-0.1.1-alpha.transport.zip` используемой установки. Сборщик не публикует пакет и не устанавливает его автоматически.

## Проверки

```bash
php tests/gallery.php
php tests/image.php
php tests/snippet.php
node --check assets/components/multipic/js/multipic.js
node tests/editor.cjs
```

GitHub Actions дополнительно создаёт одноразовый MODX 2.8.6 с MySQL, собирает/устанавливает пакет и проверяет хранилище. Результат запуска следует смотреть в Actions; наличие workflow само по себе не означает успешного прохождения.

Не запускайте `tests/integration.php` на рабочем сайте: он создаёт тестовые ресурсы и проверяет физическое удаление своих файлов.
',
    'license' => 'Copyright 2026. MultiPic project.',
    'requires' => 
    array (
      'php' => '>=7.4',
      'modx' => '>=2.8.6 <3.0.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '10b03d17829ad0be4a071e5fb4710baa',
      'native_key' => 'multipic',
      'filename' => 'modNamespace/129cd46e63308a4862495c23db9223d8.vehicle',
      'namespace' => 'multipic',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cbd0f415ddae4f3182bd5cab2f571fa8',
      'native_key' => 'multipic.folder',
      'filename' => 'modSystemSetting/39d7a7ab7b19bffcf02913620776aedb.vehicle',
      'namespace' => 'multipic',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '30b80a48b0206893f5214a34aadb1f45',
      'native_key' => 'multipic.max_files',
      'filename' => 'modSystemSetting/13aa5ecdc6f8e45888cb85193c754d81.vehicle',
      'namespace' => 'multipic',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1645f30479e1be09979bfbd000dd457c',
      'native_key' => 'multipic.max_edge',
      'filename' => 'modSystemSetting/3d2dc14e952588c0448218c1d3ad9cca.vehicle',
      'namespace' => 'multipic',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '21be1c32ccb3de04a67d254135656f2c',
      'native_key' => 'multipic.quality',
      'filename' => 'modSystemSetting/a79e3fa66fbc23e8631f55753480f7bf.vehicle',
      'namespace' => 'multipic',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c043971d9dbf152786fab0db6f75e3d1',
      'native_key' => 'multipic.max_bytes',
      'filename' => 'modSystemSetting/38ebb8b940a1c876e71c2a903e5003d7.vehicle',
      'namespace' => 'multipic',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7eb64252e6a6cda5899d11cdda612c5f',
      'native_key' => 'multipic.max_pixels',
      'filename' => 'modSystemSetting/96a9251ecc869634ae5fe4347150e9f3.vehicle',
      'namespace' => 'multipic',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '150b8b1bcbf65b7288d0aca2984c3d7d',
      'native_key' => 'multipic.chunks_path',
      'filename' => 'modSystemSetting/06d5fac5f2d2754903d7805ec0fec9bf.vehicle',
      'namespace' => 'multipic',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '7319f0effb2a38aad20e6fb1d83fc355',
      'native_key' => NULL,
      'filename' => 'modCategory/155660dc9231e5fae086a565d4c67071.vehicle',
      'namespace' => 'multipic',
    ),
  ),
);