<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '# MultiPic

Массовая загрузка изображений в TV MODX Revolution: компактные миниатюры, сортировка, название/ALT, скрытие, несколько галерей на ресурсе и подключение через `inputTV` в MIGX.

**Текущая версия: 0.1.1-alpha. Основная тестовая связка: MODX 2.8.6-pl + PHP 7.4.** Это технический выпуск для отдельного тестового сайта. MODX 3 пока исключён из установочных требований. [Результаты проверки и ограничения](docs/STATUS.md).

## Установка

1. Скачать [multipic-0.1.1-alpha.transport.zip](dist/multipic-0.1.1-alpha.transport.zip).
2. В менеджере MODX открыть «Управление пакетами», выбрать локальную загрузку и установить этот `.transport.zip`.
3. Создать TV, например `gallery`, с типом **MultiPic — галерея изображений**.
4. Указать максимум файлов и папку, например `multipic/gallery/`. На вкладке «Источники файлов» выбрать локальный файловый источник.
5. Назначить TV нужному шаблону. Открыть ресурс, загрузить фотографии, сохранить ресурс.

После установки появляются категория **MultiPic**, сниппет, плагин, настройки и примеры чанков. Самостоятельно ресурсы и TV на сайте не создаются. При обновлении пользовательские изменения демонстрационных чанков сохраняются.

Требуются PHP JSON, PDO MySQL, GD, Fileinfo и EXIF. Для WebP библиотека GD должна поддерживать этот формат. Таблицы InnoDB; рекомендуется MySQL 5.7+/MariaDB. Автоматическая очистка использует MySQL advisory locks.

## Вывод

```modx
[[MultiPic?
    &tv=`gallery`
    &tpl=`multipicItem`
    &tplWrapper=`multipicWrapper`
]]
```

Одна фотография другого ресурса:

```modx
[[MultiPic? &tv=`gallery` &resource=`123` &limit=`1`]]
```

Поддерживаются обычные чанки из админки, статические чанки по имени и файлы через `@FILE`. Примеры сниппета и Fenom `foreach` установлены в категории MultiPic. [Полная справка по текущей реализации](docs/USAGE.md).

## Документация

- [Настройка, MIGX, вывод, foreach, хранение и cron](docs/USAGE.md)
- [Что проверить на тестовом сайте](docs/ACCEPTANCE.md)
- [Согласованное техническое задание](docs/SPEC.md)
- [Статус и известные ограничения](docs/STATUS.md)
- [Изменения](CHANGELOG.md)

## Сборка из исходников

На отдельной установленной копии MODX 2.8.6:

```bash
php _build/build.transport.php /absolute/path/to/site/config.core.php
```

Результат: `core/packages/multipic-0.1.1-alpha.transport.zip` используемой установки. Сборщик не публикует пакет и не устанавливает его автоматически.

## Проверки

```bash
php tests/gallery.php
php tests/image.php
php tests/snippet.php
node --check assets/components/multipic/js/multipic.js
node tests/editor.cjs
```

GitHub Actions дополнительно создаёт одноразовый MODX 2.8.6 с MySQL, собирает/устанавливает пакет и проверяет хранилище. Результат запуска следует смотреть в Actions; наличие workflow само по себе не означает успешного прохождения.

Не запускайте `tests/integration.php` на рабочем сайте: он создаёт тестовые ресурсы и проверяет физическое удаление своих файлов.
',
    'license' => 'Copyright 2026. MultiPic project.',
    'requires' => 
    array (
      'php' => '>=7.4',
      'modx' => '>=2.8.6 <3.0.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '6c2185f9c15984bcc9d5c500bf95193e',
      'native_key' => 'multipic',
      'filename' => 'modNamespace/18c0b6383de2ed3b18f7e295b548315d.vehicle',
      'namespace' => 'multipic',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '12d0a4b0c09851dcb6743c5cc41a912b',
      'native_key' => 'multipic.folder',
      'filename' => 'modSystemSetting/fa34f7faeef05fa1f8e2fb1ff777347f.vehicle',
      'namespace' => 'multipic',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0aecd60d295fb132cea492e3c27cd5e5',
      'native_key' => 'multipic.max_files',
      'filename' => 'modSystemSetting/49462fdddc4ef0d5909c700d83e1f2cf.vehicle',
      'namespace' => 'multipic',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd2db2a177ed0e443e8b2589604108186',
      'native_key' => 'multipic.max_edge',
      'filename' => 'modSystemSetting/a6eca1b60daffc0dcdd6c236723fd8ea.vehicle',
      'namespace' => 'multipic',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d5a7076407ac6d45b46272e365bccd5',
      'native_key' => 'multipic.quality',
      'filename' => 'modSystemSetting/519cafeb93f294fd5bf94ed0473a22b9.vehicle',
      'namespace' => 'multipic',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91b71b125c25be2eb7d5577f99c38f7a',
      'native_key' => 'multipic.max_bytes',
      'filename' => 'modSystemSetting/254cb294c7bdae0d9d13505c48b06853.vehicle',
      'namespace' => 'multipic',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a447104a08e5fb13f5476330b692add1',
      'native_key' => 'multipic.max_pixels',
      'filename' => 'modSystemSetting/475320369ecdc0c08557a46ce611111e.vehicle',
      'namespace' => 'multipic',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b0fcb1e66dce827412c122e9128e23f9',
      'native_key' => 'multipic.chunks_path',
      'filename' => 'modSystemSetting/1faab710d0309465f0954d1cdd65b03e.vehicle',
      'namespace' => 'multipic',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '23ac61209fff86f53184cbb21a456b67',
      'native_key' => NULL,
      'filename' => 'modCategory/1decc3fef557be6c6d635e8e8c65e37c.vehicle',
      'namespace' => 'multipic',
    ),
  ),
);