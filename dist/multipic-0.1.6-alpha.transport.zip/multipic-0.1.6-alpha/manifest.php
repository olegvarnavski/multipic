<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '# MultiPic

Массовая загрузка изображений в TV MODX Revolution: компактные миниатюры, сортировка, название/ALT, скрытие, несколько галерей на ресурсе и подключение через `inputTV` в MIGX.

**Текущая версия: 0.1.6-alpha. Целевая ветка: MODX 2.x начиная с 2.6.0, PHP 7.4+ (полная интеграция проверяется на PHP 7.4, PHP 8.2 — отдельно unit). Проверены MODX 2.6.0, 2.6.5, 2.8.5 и 2.8.6 на PHP 7.4.** Это технический выпуск для отдельного тестового сайта. MODX 3 пока исключён из установочных требований. [Результаты проверки и ограничения](docs/STATUS.md).

## Установка

1. Скачать [multipic-0.1.6-alpha.transport.zip](dist/multipic-0.1.6-alpha.transport.zip).
2. В менеджере MODX открыть «Управление пакетами», выбрать локальную загрузку и установить этот `.transport.zip`.
3. Создать TV, например `gallery`, с типом **MultiPic — галерея изображений**.
4. Указать максимум файлов и папку, например `multipic/gallery/`. На вкладке «Источники файлов» выбрать локальный файловый источник.
5. Назначить TV нужному шаблону. Открыть ресурс, загрузить фотографии, сохранить ресурс.

После установки появляются категория **MultiPic**, сниппет, плагин, настройки и примеры чанков. Самостоятельно ресурсы и TV на сайте не создаются. При обновлении пользовательские изменения демонстрационных чанков сохраняются.

Сторонние дополнения для самостоятельной работы не нужны. Для загрузки пользователь должен иметь право `file_upload`; ограничения типов источника учитываются. Требования к платформе проверяются валидатором установки без вкладки пакетных зависимостей. Требуются PHP JSON, PDO MySQL, GD, Fileinfo и EXIF. Для WebP библиотека GD должна поддерживать этот формат. Таблицы InnoDB; рекомендуется MySQL 5.7+/MariaDB. Автоматическая очистка использует MySQL advisory locks.

## Вывод

```modx
[[MultiPic?
    &tv=`gallery`
    &tpl=`multipicItem`
    &tplWrapper=`multipicWrapper`
]]
```

Одна фотография другого ресурса:

```modx
[[MultiPic? &tv=`gallery` &resource=`123` &limit=`1`]]
```

Поддерживаются обычные чанки из админки, статические чанки по имени и файлы через `@FILE`. Примеры сниппета и Fenom `foreach` установлены в категории MultiPic. [Полная справка по текущей реализации](docs/USAGE.md).

## Документация

- [Оставшиеся задачи и ручная приёмка](docs/ROADMAP.md)

- [Настройка, MIGX, вывод, foreach, хранение и cron](docs/USAGE.md)
- [Что проверить на тестовом сайте](docs/ACCEPTANCE.md)
- [Согласованное техническое задание](docs/SPEC.md)
- [Статус и известные ограничения](docs/STATUS.md)
- [Изменения](CHANGELOG.md)

## Сборка из исходников

На отдельной установленной копии MODX 2.8.6:

```bash
php _build/build.transport.php /absolute/path/to/site/config.core.php
```

Результат: `core/packages/multipic-0.1.6-alpha.transport.zip` используемой установки. Сборщик не публикует пакет и не устанавливает его автоматически.

## Проверки

```bash
php tests/gallery.php
php tests/image.php
php tests/snippet.php
node --check assets/components/multipic/js/multipic.js
node tests/editor.cjs
```

Проверка [MODX 2.6.0, 2.6.5, 2.8.5 и 2.8.6 / PHP 7.4.33 / MySQL 5.7 прошла](https://github.com/olegvarnavski/multipic/actions/runs/40319474785): установка, загрузка, дедупликация, вывод, копирование ресурса и удаление файлов. Также проверены вход/рендер TV/загрузка/сохранение ресурса через HTTP и токены при раннем закрытии PHP-сессии. Установщик в dist взят из задания MODX 2.8.5 этого прогона. Проверено обновление с 0.1.3 с сохранением пользовательских данных и отдельные unit на PHP 8.2. Для DOM-тестов разработчика: `npm ci && npm test`; на сайт Node/npm не устанавливаются. Ручная приёмка реального менеджера и MIGX ещё нужна.

Не запускайте `tests/integration.php` на рабочем сайте: он создаёт тестовые ресурсы и проверяет физическое удаление своих файлов.
',
    'license' => 'Copyright 2026. MultiPic project.',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'db5661b056e853231994ff6112844db5',
      'native_key' => 'multipic',
      'filename' => 'modNamespace/6067839d295f15c3f0d24a58247425e5.vehicle',
      'namespace' => 'multipic',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '13222e662f40d8d6b6f75f64533db48c',
      'native_key' => 'multipic.folder',
      'filename' => 'modSystemSetting/17e8e6cdc15674d03cdad1d6f6e27b52.vehicle',
      'namespace' => 'multipic',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd7c4a46c8307a56ca69d1604f3b7190',
      'native_key' => 'multipic.max_files',
      'filename' => 'modSystemSetting/2a3b70ac23278199a716a07e0e369af1.vehicle',
      'namespace' => 'multipic',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f0bce1465223cc6f1c58e4a4e38af2da',
      'native_key' => 'multipic.max_edge',
      'filename' => 'modSystemSetting/e7817a3423fc2c4fea137854ea5d8399.vehicle',
      'namespace' => 'multipic',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3bf575f876d2314104249f9ab6c91696',
      'native_key' => 'multipic.quality',
      'filename' => 'modSystemSetting/87d0e8f744a7aaf15ad6c1654ca3d868.vehicle',
      'namespace' => 'multipic',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '29e42ad38a2fc0ee1bf69713dea29495',
      'native_key' => 'multipic.max_bytes',
      'filename' => 'modSystemSetting/248fbdae45b7fb5d1b4bfd5d1bc3247d.vehicle',
      'namespace' => 'multipic',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '92628bf62d38ca1b27d43631f64a0bab',
      'native_key' => 'multipic.max_pixels',
      'filename' => 'modSystemSetting/66f11f2cd7efd055218e8a7f5c7681e5.vehicle',
      'namespace' => 'multipic',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a8eba5f92b3c699483591d09a0a6ba3',
      'native_key' => 'multipic.chunks_path',
      'filename' => 'modSystemSetting/3bf5d11088efe919765bf199cedab90b.vehicle',
      'namespace' => 'multipic',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'e5e09e37c42c4fc3cb8fa3d949ebc407',
      'native_key' => NULL,
      'filename' => 'modCategory/1c956eb10a6902208e38b40dd56ec920.vehicle',
      'namespace' => 'multipic',
    ),
  ),
);