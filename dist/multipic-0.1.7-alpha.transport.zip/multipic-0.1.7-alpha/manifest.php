<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '# MultiPic

Массовая загрузка изображений в TV MODX Revolution: компактные миниатюры, сортировка, название/ALT, скрытие, несколько галерей на ресурсе и подключение через `inputTV` в MIGX.

**Текущая версия: 0.1.7-alpha. Целевая ветка: MODX 2.x начиная с 2.6.0, PHP 7.4+ (полная интеграция проверяется на PHP 7.4, PHP 8.2 — отдельно unit). Проверены MODX 2.6.0, 2.6.5, 2.8.5 и 2.8.6 на PHP 7.4.** Это технический выпуск для отдельного тестового сайта. MODX 3 пока исключён из установочных требований. [Результаты проверки и ограничения](docs/STATUS.md).

## Установка

1. Скачать [multipic-0.1.7-alpha.transport.zip](dist/multipic-0.1.7-alpha.transport.zip).
2. В менеджере MODX открыть «Управление пакетами», выбрать локальную загрузку и установить этот `.transport.zip`.
3. Создать TV, например `gallery`, с типом **MultiPic — галерея изображений**.
4. Указать максимум файлов и папку, например `multipic/gallery/`. На вкладке «Источники файлов» выбрать локальный файловый источник.
5. Назначить TV нужному шаблону. Открыть ресурс, загрузить фотографии, сохранить ресурс.

После установки появляются категория **MultiPic**, сниппет, плагин, настройки и примеры чанков. Самостоятельно ресурсы и TV на сайте не создаются. При обновлении пользовательские изменения демонстрационных чанков сохраняются.

Сторонние дополнения для самостоятельной работы не нужны. Для загрузки пользователь должен иметь право `file_upload`; ограничения типов источника учитываются. Требования к платформе проверяются валидатором установки без вкладки пакетных зависимостей. Требуются PHP JSON, PDO MySQL, GD, Fileinfo и EXIF. Для WebP библиотека GD должна поддерживать этот формат. Таблицы InnoDB; рекомендуется MySQL 5.7+/MariaDB. Автоматическая очистка использует MySQL advisory locks.

## Вывод

```modx
[[MultiPic?
    &tv=`gallery`
    &tpl=`multipicItem`
    &tplWrapper=`multipicWrapper`
]]
```

Одна фотография другого ресурса:

```modx
[[MultiPic? &tv=`gallery` &resource=`123` &limit=`1`]]
```

Поддерживаются обычные чанки из админки, статические чанки по имени и файлы через `@FILE`. Примеры сниппета и Fenom `foreach` установлены в категории MultiPic. [Полная справка по текущей реализации](docs/USAGE.md).

## Документация

- [Оставшиеся задачи и ручная приёмка](docs/ROADMAP.md)

- [Настройка, MIGX, вывод, foreach, хранение и cron](docs/USAGE.md)
- [Что проверить на тестовом сайте](docs/ACCEPTANCE.md)
- [Согласованное техническое задание](docs/SPEC.md)
- [Статус и известные ограничения](docs/STATUS.md)
- [Изменения](CHANGELOG.md)

## Сборка из исходников

На отдельной установленной копии MODX 2.8.6:

```bash
php _build/build.transport.php /absolute/path/to/site/config.core.php
```

Результат: `core/packages/multipic-0.1.7-alpha.transport.zip` используемой установки. Сборщик не публикует пакет и не устанавливает его автоматически.

## Проверки

```bash
php tests/gallery.php
php tests/image.php
php tests/snippet.php
node --check assets/components/multipic/js/multipic.js
node tests/editor.cjs
```

Проверка [MODX 2.6.0, 2.6.5, 2.8.5 и 2.8.6 / PHP 7.4.33 / MySQL 5.7 прошла](https://github.com/olegvarnavski/multipic/actions/runs/40323357142): установка, загрузка, дедупликация, вывод, копирование ресурса и удаление файлов. Также проверены вход/рендер TV/загрузка/сохранение ресурса через HTTP и токены при раннем закрытии PHP-сессии. Установщик в dist взят из задания MODX 2.8.5 этого прогона. Проверено обновление с 0.1.3 с сохранением пользовательских данных и отдельные unit на PHP 8.2. Для DOM-тестов разработчика: `npm ci && npm test`; на сайт Node/npm не устанавливаются. Ручная приёмка реального менеджера и MIGX ещё нужна.

Не запускайте `tests/integration.php` на рабочем сайте: он создаёт тестовые ресурсы и проверяет физическое удаление своих файлов.
',
    'license' => 'Copyright 2026. MultiPic project.',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '1147c0acbcffbe07e6f426db45aad9be',
      'native_key' => 'multipic',
      'filename' => 'modNamespace/9551b1c61c8f6eed45722da4637e952f.vehicle',
      'namespace' => 'multipic',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '826e64a6581a5691df5f2e4720a0e9ef',
      'native_key' => 'multipic.folder',
      'filename' => 'modSystemSetting/79bfd14ef72f373f704ca5308ba84285.vehicle',
      'namespace' => 'multipic',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2febf63225c67b29f45f06b8688b91a7',
      'native_key' => 'multipic.max_files',
      'filename' => 'modSystemSetting/e415ed87f268d83c2ae8ce34b9dd8e51.vehicle',
      'namespace' => 'multipic',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b7a585c69d71eb74dc5e1c07ca35849c',
      'native_key' => 'multipic.max_edge',
      'filename' => 'modSystemSetting/d72df9ba87e7170aa58c2c48c5589385.vehicle',
      'namespace' => 'multipic',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '88ccb6d5a193361accb6a35dec5ec1d3',
      'native_key' => 'multipic.quality',
      'filename' => 'modSystemSetting/ae7f5aabbaacbc20015bf956e8aa6fac.vehicle',
      'namespace' => 'multipic',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8a676f12c7b50a9008e00ebc30bcbec4',
      'native_key' => 'multipic.max_bytes',
      'filename' => 'modSystemSetting/90361289cb743abcb9c8be01dfb4c7ac.vehicle',
      'namespace' => 'multipic',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '51db28d75ecbfe0ba591443a5928e45a',
      'native_key' => 'multipic.chunks_path',
      'filename' => 'modSystemSetting/a5438cef624cc0b321e353fa351c6bea.vehicle',
      'namespace' => 'multipic',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'e66a3c3616e18897fec72333ef6aa438',
      'native_key' => NULL,
      'filename' => 'modCategory/d3da46e200404d103b32e8d053edd7a3.vehicle',
      'namespace' => 'multipic',
    ),
  ),
);