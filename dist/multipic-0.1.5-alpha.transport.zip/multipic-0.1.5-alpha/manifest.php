<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '# MultiPic

Массовая загрузка изображений в TV MODX Revolution: компактные миниатюры, сортировка, название/ALT, скрытие, несколько галерей на ресурсе и подключение через `inputTV` в MIGX.

**Текущая версия: 0.1.5-alpha. Целевая ветка: MODX 2.x начиная с 2.6.0, PHP 7.4+ (полная интеграция проверяется на PHP 7.4, PHP 8.2 — отдельно unit). Проверены MODX 2.6.0, 2.6.5, 2.8.5 и 2.8.6 на PHP 7.4.** Это технический выпуск для отдельного тестового сайта. MODX 3 пока исключён из установочных требований. [Результаты проверки и ограничения](docs/STATUS.md).

## Установка

1. Скачать [multipic-0.1.5-alpha.transport.zip](dist/multipic-0.1.5-alpha.transport.zip).
2. В менеджере MODX открыть «Управление пакетами», выбрать локальную загрузку и установить этот `.transport.zip`.
3. Создать TV, например `gallery`, с типом **MultiPic — галерея изображений**.
4. Указать максимум файлов и папку, например `multipic/gallery/`. На вкладке «Источники файлов» выбрать локальный файловый источник.
5. Назначить TV нужному шаблону. Открыть ресурс, загрузить фотографии, сохранить ресурс.

После установки появляются категория **MultiPic**, сниппет, плагин, настройки и примеры чанков. Самостоятельно ресурсы и TV на сайте не создаются. При обновлении пользовательские изменения демонстрационных чанков сохраняются.

Сторонние дополнения для самостоятельной работы не нужны. Для загрузки пользователь должен иметь право `file_upload`; ограничения типов источника учитываются. Требования к платформе проверяются валидатором установки без вкладки пакетных зависимостей. Требуются PHP JSON, PDO MySQL, GD, Fileinfo и EXIF. Для WebP библиотека GD должна поддерживать этот формат. Таблицы InnoDB; рекомендуется MySQL 5.7+/MariaDB. Автоматическая очистка использует MySQL advisory locks.

## Вывод

```modx
[[MultiPic?
    &tv=`gallery`
    &tpl=`multipicItem`
    &tplWrapper=`multipicWrapper`
]]
```

Одна фотография другого ресурса:

```modx
[[MultiPic? &tv=`gallery` &resource=`123` &limit=`1`]]
```

Поддерживаются обычные чанки из админки, статические чанки по имени и файлы через `@FILE`. Примеры сниппета и Fenom `foreach` установлены в категории MultiPic. [Полная справка по текущей реализации](docs/USAGE.md).

## Документация

- [Оставшиеся задачи и ручная приёмка](docs/ROADMAP.md)

- [Настройка, MIGX, вывод, foreach, хранение и cron](docs/USAGE.md)
- [Что проверить на тестовом сайте](docs/ACCEPTANCE.md)
- [Согласованное техническое задание](docs/SPEC.md)
- [Статус и известные ограничения](docs/STATUS.md)
- [Изменения](CHANGELOG.md)

## Сборка из исходников

На отдельной установленной копии MODX 2.8.6:

```bash
php _build/build.transport.php /absolute/path/to/site/config.core.php
```

Результат: `core/packages/multipic-0.1.5-alpha.transport.zip` используемой установки. Сборщик не публикует пакет и не устанавливает его автоматически.

## Проверки

```bash
php tests/gallery.php
php tests/image.php
php tests/snippet.php
node --check assets/components/multipic/js/multipic.js
node tests/editor.cjs
```

Проверка [MODX 2.6.0, 2.6.5, 2.8.5 и 2.8.6 / PHP 7.4.33 / MySQL 5.7 прошла](https://github.com/olegvarnavski/multipic/actions/runs/39963559991): установка, загрузка, дедупликация, вывод, копирование ресурса и удаление файлов. Также проверены вход/рендер TV/загрузка/сохранение ресурса через HTTP и токены при раннем закрытии PHP-сессии. Установщик в dist взят из задания MODX 2.8.5 этого прогона. Проверено обновление с 0.1.3 с сохранением пользовательских данных и отдельные unit на PHP 8.2. Для DOM-тестов разработчика: `npm ci && npm test`; на сайт Node/npm не устанавливаются. Ручная приёмка реального менеджера и MIGX ещё нужна.

Не запускайте `tests/integration.php` на рабочем сайте: он создаёт тестовые ресурсы и проверяет физическое удаление своих файлов.
',
    'license' => 'Copyright 2026. MultiPic project.',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '06d118052e131365c9b2db206e1a5930',
      'native_key' => 'multipic',
      'filename' => 'modNamespace/29e84495e9a8f76ebbf14f39eb1054ce.vehicle',
      'namespace' => 'multipic',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2533592da5f20c6aa40406bd63df7e91',
      'native_key' => 'multipic.folder',
      'filename' => 'modSystemSetting/035a253e6d6718ba589f98a43067a1cc.vehicle',
      'namespace' => 'multipic',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e5d20b4b1dd97660ac63b3b2ee57f05',
      'native_key' => 'multipic.max_files',
      'filename' => 'modSystemSetting/311ef40f7e1c9db7e6aafb6b944fc148.vehicle',
      'namespace' => 'multipic',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3aca72746c8ec2a59a101fdb07899801',
      'native_key' => 'multipic.max_edge',
      'filename' => 'modSystemSetting/d365057e565ddbbd3afdc129eeb61e28.vehicle',
      'namespace' => 'multipic',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53bd792dd96a9518f69a492230387f6f',
      'native_key' => 'multipic.quality',
      'filename' => 'modSystemSetting/d77ac2471fa975beb997e8933f5a1a4d.vehicle',
      'namespace' => 'multipic',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1628d9f152011cd97e551b3315656521',
      'native_key' => 'multipic.max_bytes',
      'filename' => 'modSystemSetting/796678964ffd90fa8b18f76bab6868de.vehicle',
      'namespace' => 'multipic',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a67065419689db09a487154a174143f7',
      'native_key' => 'multipic.max_pixels',
      'filename' => 'modSystemSetting/5dbad2b34942548a2b0ccaf67aa843f4.vehicle',
      'namespace' => 'multipic',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '795ed83a9e6e5f3bdbaacbee0de54d40',
      'native_key' => 'multipic.chunks_path',
      'filename' => 'modSystemSetting/b6695b39aefcf281f103976af7c46297.vehicle',
      'namespace' => 'multipic',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '9c8434291365725fac3d3b0218b2c076',
      'native_key' => NULL,
      'filename' => 'modCategory/8c04b609a1c643788c17593403c4721b.vehicle',
      'namespace' => 'multipic',
    ),
  ),
);