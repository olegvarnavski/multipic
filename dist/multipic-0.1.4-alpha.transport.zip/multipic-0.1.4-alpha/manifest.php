<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '# MultiPic

Массовая загрузка изображений в TV MODX Revolution: компактные миниатюры, сортировка, название/ALT, скрытие, несколько галерей на ресурсе и подключение через `inputTV` в MIGX.

**Текущая версия: 0.1.4-alpha. Целевая ветка: MODX 2.x начиная с 2.6.0, PHP 7.4+ (полная интеграция проверяется на PHP 7.4, PHP 8.2 — отдельно unit). Проверены MODX 2.6.0, 2.6.5, 2.8.5 и 2.8.6 на PHP 7.4.** Это технический выпуск для отдельного тестового сайта. MODX 3 пока исключён из установочных требований. [Результаты проверки и ограничения](docs/STATUS.md).

## Установка

1. Скачать [multipic-0.1.4-alpha.transport.zip](dist/multipic-0.1.4-alpha.transport.zip).
2. В менеджере MODX открыть «Управление пакетами», выбрать локальную загрузку и установить этот `.transport.zip`.
3. Создать TV, например `gallery`, с типом **MultiPic — галерея изображений**.
4. Указать максимум файлов и папку, например `multipic/gallery/`. На вкладке «Источники файлов» выбрать локальный файловый источник.
5. Назначить TV нужному шаблону. Открыть ресурс, загрузить фотографии, сохранить ресурс.

После установки появляются категория **MultiPic**, сниппет, плагин, настройки и примеры чанков. Самостоятельно ресурсы и TV на сайте не создаются. При обновлении пользовательские изменения демонстрационных чанков сохраняются.

Сторонние дополнения для самостоятельной работы не нужны. Для загрузки пользователь должен иметь право `file_upload`; ограничения типов источника учитываются. Требования к платформе проверяются валидатором установки без вкладки пакетных зависимостей. Требуются PHP JSON, PDO MySQL, GD, Fileinfo и EXIF. Для WebP библиотека GD должна поддерживать этот формат. Таблицы InnoDB; рекомендуется MySQL 5.7+/MariaDB. Автоматическая очистка использует MySQL advisory locks.

## Вывод

```modx
[[MultiPic?
    &tv=`gallery`
    &tpl=`multipicItem`
    &tplWrapper=`multipicWrapper`
]]
```

Одна фотография другого ресурса:

```modx
[[MultiPic? &tv=`gallery` &resource=`123` &limit=`1`]]
```

Поддерживаются обычные чанки из админки, статические чанки по имени и файлы через `@FILE`. Примеры сниппета и Fenom `foreach` установлены в категории MultiPic. [Полная справка по текущей реализации](docs/USAGE.md).

## Документация

- [Оставшиеся задачи и ручная приёмка](docs/ROADMAP.md)

- [Настройка, MIGX, вывод, foreach, хранение и cron](docs/USAGE.md)
- [Что проверить на тестовом сайте](docs/ACCEPTANCE.md)
- [Согласованное техническое задание](docs/SPEC.md)
- [Статус и известные ограничения](docs/STATUS.md)
- [Изменения](CHANGELOG.md)

## Сборка из исходников

На отдельной установленной копии MODX 2.8.6:

```bash
php _build/build.transport.php /absolute/path/to/site/config.core.php
```

Результат: `core/packages/multipic-0.1.4-alpha.transport.zip` используемой установки. Сборщик не публикует пакет и не устанавливает его автоматически.

## Проверки

```bash
php tests/gallery.php
php tests/image.php
php tests/snippet.php
node --check assets/components/multipic/js/multipic.js
node tests/editor.cjs
```

Проверка [MODX 2.6.0, 2.6.5, 2.8.5 и 2.8.6 / PHP 7.4.33 / MySQL 5.7 прошла](https://github.com/olegvarnavski/multipic/actions/runs/39115325253): установка, загрузка, дедупликация, вывод, копирование ресурса и удаление файлов. Также проверены вход/рендер TV/загрузка/сохранение ресурса через HTTP и токены при раннем закрытии PHP-сессии. Установщик в dist взят из задания MODX 2.8.5 этого прогона. Для DOM-тестов разработчика: `npm ci && npm test`; на сайт Node/npm не устанавливаются. Ручная приёмка реального менеджера и MIGX ещё нужна.

Не запускайте `tests/integration.php` на рабочем сайте: он создаёт тестовые ресурсы и проверяет физическое удаление своих файлов.
',
    'license' => 'Copyright 2026. MultiPic project.',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '5ff479698e8c9401f79a09ac6c1361aa',
      'native_key' => 'multipic',
      'filename' => 'modNamespace/4acb8ea32fcf5071dcc01a0a03ebac47.vehicle',
      'namespace' => 'multipic',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dde69b6d38fcdabf398df86c32944786',
      'native_key' => 'multipic.folder',
      'filename' => 'modSystemSetting/1922976e2888346e11c01181fac071f9.vehicle',
      'namespace' => 'multipic',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '60881093f46614afca205513b383f39a',
      'native_key' => 'multipic.max_files',
      'filename' => 'modSystemSetting/324a146d98eb376b7579f1f6c7463827.vehicle',
      'namespace' => 'multipic',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '18a167f361261c6f521b9855018d32ea',
      'native_key' => 'multipic.max_edge',
      'filename' => 'modSystemSetting/9aa0a45997b0901cbbe50624afdd0dcf.vehicle',
      'namespace' => 'multipic',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6a132d6018df1804dc44168a70833d7',
      'native_key' => 'multipic.quality',
      'filename' => 'modSystemSetting/9d50a5c3f2d051b63e33038d0fb523a6.vehicle',
      'namespace' => 'multipic',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '73df30f0b736275fdf7c0153c91bdd8a',
      'native_key' => 'multipic.max_bytes',
      'filename' => 'modSystemSetting/8f8ecb9dbf9c0a786dd08473076d8cba.vehicle',
      'namespace' => 'multipic',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7e2dfa18064f1ee34eccdaf1d99aee15',
      'native_key' => 'multipic.max_pixels',
      'filename' => 'modSystemSetting/894acd20dff57df2f3f90f87ff65ff6f.vehicle',
      'namespace' => 'multipic',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bcda17e6fb132d564148bf27e34ec7ed',
      'native_key' => 'multipic.chunks_path',
      'filename' => 'modSystemSetting/9d57d3e5d705d152fce22fd3aab1b67a.vehicle',
      'namespace' => 'multipic',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '52af4e94b73866fd3820351d1a236656',
      'native_key' => NULL,
      'filename' => 'modCategory/3d31e5eca2b4bd7cdc9a454772727912.vehicle',
      'namespace' => 'multipic',
    ),
  ),
);